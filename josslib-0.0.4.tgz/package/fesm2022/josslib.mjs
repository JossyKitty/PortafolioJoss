import * as i0 from '@angular/core';
import { Component, DOCUMENT, Inject, Injectable, EventEmitter, inject, Output, Input, HostListener, ViewChild } from '@angular/core';
import * as i2 from '@angular/common';
import { CommonModule, ViewportScroller, NgClass } from '@angular/common';
import * as i1 from '@angular/router';
import { RouterModule, Router, ActivatedRoute, NavigationEnd, NavigationSkipped, NavigationSkippedCode, RouterLink } from '@angular/router';

class Josslib {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: Josslib, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.15", type: Josslib, isStandalone: true, selector: "lib-josslib", ngImport: i0, template: ` <p>josslib works!</p> `, isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: Josslib, decorators: [{
            type: Component,
            args: [{ selector: 'lib-josslib', imports: [], template: ` <p>josslib works!</p> ` }]
        }] });

class ThemeService {
    document;
    constructor(document) {
        this.document = document;
        this.getTheme();
    }
    darkMode = false;
    temas = ['josselyn', 'josselyn-dark'];
    loadTheme() {
        const tema = this.darkMode ? this.temas[1] : this.temas[0];
        localStorage.setItem('theme', tema);
        let themeLink = this.document.getElementById('app-theme');
        if (themeLink) {
            themeLink.href = tema + '.css';
        }
    }
    switchTheme() {
        this.darkMode = !this.darkMode;
        this.loadTheme();
    }
    getTheme() {
        let lsTheme = localStorage.getItem('theme');
        if (lsTheme != null) {
            this.darkMode = lsTheme === this.temas[1];
        }
        else {
            //Si el usuario no ha configurado / cambiado su tema, se usa el que detecte el navegador.
            this.darkMode = window.matchMedia('(prefers-color-scheme: dark)').matches;
        }
        this.loadTheme();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: ThemeService, deps: [{ token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: ThemeService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: ThemeService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }] });

class Header {
    links = [];
    showThemeButton = true;
    darkMode = false;
    useInternalThemeService = true;
    darkModeChange = new EventEmitter();
    openedMenu = false;
    themeService = inject(ThemeService);
    ngAfterViewInit() {
        this.darkMode = this.themeService.darkMode;
    }
    switchTheme() {
        this.darkMode = !this.darkMode;
        this.darkModeChange.emit(this.darkMode);
        if (this.useInternalThemeService) {
            this.themeService.switchTheme();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: Header, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.15", type: Header, isStandalone: true, selector: "jl-header", inputs: { links: "links", showThemeButton: "showThemeButton", darkMode: "darkMode", useInternalThemeService: "useInternalThemeService" }, outputs: { darkModeChange: "darkModeChange" }, ngImport: i0, template: "<header class=\"jl-header\">\n  @if (links.length > 0) {\n    <button\n      class=\"jl-header__menu-hamburguesa jl-icon-btn\"\n      [ariaLabel]=\"openedMenu ? 'Cerrar men\u00FA' : 'Abrir men\u00FA'\"\n      (click)=\"openedMenu = !openedMenu\"\n    >\n      <div\n        [ngClass]=\"{\n          'jl-header__icon-hamburguesa': true,\n          'jl-header__icon-hamburguesa--opened': openedMenu,\n        }\"\n      >\n        <div class=\"jl-header__icon-hamburguesa-line jl-header__icon-hamburguesa-line--top\"></div>\n        <div\n          class=\"jl-header__icon-hamburguesa-line jl-header__icon-hamburguesa-line--middle\"\n        ></div>\n        <div\n          class=\"jl-header__icon-hamburguesa-line jl-header__icon-hamburguesa-line--bottom\"\n        ></div>\n      </div>\n    </button>\n  }\n  <div class=\"jl-header__title\">Josselyn MM</div>\n  <nav class=\"jl-header__menu\" animate.enter=\"jl-fade-in\" animate.leave=\"jl-fade-out\">\n    <ul class=\"jl-header__menu-list\">\n      @for (linkItem of links; track linkItem.label) {\n        <li>\n          <a [routerLink]=\"linkItem.link\" class=\"jl-header__menu-item\" role=\"link\">\n            <span class=\"jl-header__menu-link\">{{ linkItem.label }}</span>\n          </a>\n        </li>\n      }\n    </ul>\n  </nav>\n  @if (showThemeButton) {\n    <button\n      [ngClass]=\"{\n        'jl-icon-btn jl-header__darkmode-switch pi': true,\n        'pi-moon': !darkMode,\n        'pi-sun': darkMode,\n      }\"\n      [aria-label]=\"darkMode ? 'Cambiar a modo claro' : 'Cambiar a modo oscuro'\"\n      (click)=\"switchTheme()\"\n    ></button>\n  }\n</header>\n", styles: [".jl-header{display:flex;flex-direction:row;align-items:center;background-color:var(--primary-dark);padding:.5em 1em;color:var(--shade-0);width:100%;position:sticky;z-index:1;top:0;left:0;height:5em;box-shadow:0 .25em .25em #00000040}.jl-header__icon-hamburguesa{width:1.4em;display:flex;flex-direction:column;gap:.25em}.jl-header__icon-hamburguesa--opened .jl-header__icon-hamburguesa-line{left:.15em}.jl-header__icon-hamburguesa--opened .jl-header__icon-hamburguesa-line--middle{opacity:0}.jl-header__icon-hamburguesa--opened .jl-header__icon-hamburguesa-line--top{transform:rotate(45deg)}.jl-header__icon-hamburguesa--opened .jl-header__icon-hamburguesa-line--bottom{transform:rotate(-45deg)}.jl-header__icon-hamburguesa-line{width:100%;height:.2em;background-color:var(--shade-0);transition:all .6s ease-out;position:relative;transform-origin:8% 50%}.jl-header__menu-hamburguesa{border:.2em solid var(--shade-0);border-radius:.5em;display:none;align-items:center;justify-content:center;aspect-ratio:1;margin-right:1em}.jl-header__menu-hamburguesa:hover,.jl-header__menu-hamburguesa:focus{border-color:var(--primary-lighter)}.jl-header__menu-hamburguesa:hover .jl-header__icon-hamburguesa-line,.jl-header__menu-hamburguesa:focus .jl-header__icon-hamburguesa-line{background-color:var(--primary-lighter)}.jl-header__menu-hamburguesa:active{border-color:var(--primary-light)}.jl-header__menu-hamburguesa:active .jl-header__icon-hamburguesa-line{background-color:var(--primary-light)}.jl-header__title{font-size:2em;font-family:var(--font-title);margin-right:auto}.jl-header__menu-list{display:flex;flex-direction:row;gap:1.6em;list-style-type:none;margin:0;padding:0}.jl-header__menu-item{cursor:pointer;text-decoration:none}.jl-header__menu-item:hover,.jl-header__menu-item:focus{scale:1.1}.jl-header__menu-item:active{scale:.9}.jl-header__menu-link{color:var(--shade-0);font-weight:700;font-size:1.5em}.jl-header__menu-link:hover,.jl-header__menu-link:focus{color:var(--primary-lighter)}.jl-header__menu-link:active{color:var(--primary-light)}.jl-header__darkmode-switch{color:var(--shade-0);font-size:1.5em;font-weight:700;margin-left:.6em}.jl-header__darkmode-switch:hover,.jl-header__darkmode-switch:focus{color:var(--primary-lighter);scale:1.1}.jl-header__darkmode-switch:active{color:var(--primary-light);scale:.9}@media(max-width:1100px){.jl-header__title{font-size:1.6em}.jl-header__menu-list{gap:.8em}.jl-header__menu-link{font-size:1.2em}}@media(max-width:800px){.jl-header__menu{display:none;position:absolute;top:5em;left:0;background-color:var(--primary-light);padding:1em .2em;border-radius:0 0 .5em .5em;box-shadow:.3em .3em .3em .1em var(--shade-200)}.jl-header__menu-hamburguesa{display:flex}.jl-header__menu-hamburguesa:has(.jl-header__icon-hamburguesa--opened)~.jl-header__menu{display:flex}.jl-header__menu-list{flex-direction:column;gap:0;overflow:hidden;padding-right:1em}.jl-header__menu-item{width:100%;display:flex;align-items:center;padding:.8em}.jl-header__menu-item:hover{background-color:var(--primary-lighter);left:5%;position:relative}.jl-header__menu-link{color:var(--primary-darker)}.jl-header__menu-link:hover,.jl-header__menu-link:active,.jl-header__menu-link:focus{color:var(--primary-darker)}}\n"], dependencies: [{ kind: "ngmodule", type: RouterModule }, { kind: "directive", type: i1.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: Header, decorators: [{
            type: Component,
            args: [{ selector: 'jl-header', imports: [RouterModule, CommonModule], standalone: true, template: "<header class=\"jl-header\">\n  @if (links.length > 0) {\n    <button\n      class=\"jl-header__menu-hamburguesa jl-icon-btn\"\n      [ariaLabel]=\"openedMenu ? 'Cerrar men\u00FA' : 'Abrir men\u00FA'\"\n      (click)=\"openedMenu = !openedMenu\"\n    >\n      <div\n        [ngClass]=\"{\n          'jl-header__icon-hamburguesa': true,\n          'jl-header__icon-hamburguesa--opened': openedMenu,\n        }\"\n      >\n        <div class=\"jl-header__icon-hamburguesa-line jl-header__icon-hamburguesa-line--top\"></div>\n        <div\n          class=\"jl-header__icon-hamburguesa-line jl-header__icon-hamburguesa-line--middle\"\n        ></div>\n        <div\n          class=\"jl-header__icon-hamburguesa-line jl-header__icon-hamburguesa-line--bottom\"\n        ></div>\n      </div>\n    </button>\n  }\n  <div class=\"jl-header__title\">Josselyn MM</div>\n  <nav class=\"jl-header__menu\" animate.enter=\"jl-fade-in\" animate.leave=\"jl-fade-out\">\n    <ul class=\"jl-header__menu-list\">\n      @for (linkItem of links; track linkItem.label) {\n        <li>\n          <a [routerLink]=\"linkItem.link\" class=\"jl-header__menu-item\" role=\"link\">\n            <span class=\"jl-header__menu-link\">{{ linkItem.label }}</span>\n          </a>\n        </li>\n      }\n    </ul>\n  </nav>\n  @if (showThemeButton) {\n    <button\n      [ngClass]=\"{\n        'jl-icon-btn jl-header__darkmode-switch pi': true,\n        'pi-moon': !darkMode,\n        'pi-sun': darkMode,\n      }\"\n      [aria-label]=\"darkMode ? 'Cambiar a modo claro' : 'Cambiar a modo oscuro'\"\n      (click)=\"switchTheme()\"\n    ></button>\n  }\n</header>\n", styles: [".jl-header{display:flex;flex-direction:row;align-items:center;background-color:var(--primary-dark);padding:.5em 1em;color:var(--shade-0);width:100%;position:sticky;z-index:1;top:0;left:0;height:5em;box-shadow:0 .25em .25em #00000040}.jl-header__icon-hamburguesa{width:1.4em;display:flex;flex-direction:column;gap:.25em}.jl-header__icon-hamburguesa--opened .jl-header__icon-hamburguesa-line{left:.15em}.jl-header__icon-hamburguesa--opened .jl-header__icon-hamburguesa-line--middle{opacity:0}.jl-header__icon-hamburguesa--opened .jl-header__icon-hamburguesa-line--top{transform:rotate(45deg)}.jl-header__icon-hamburguesa--opened .jl-header__icon-hamburguesa-line--bottom{transform:rotate(-45deg)}.jl-header__icon-hamburguesa-line{width:100%;height:.2em;background-color:var(--shade-0);transition:all .6s ease-out;position:relative;transform-origin:8% 50%}.jl-header__menu-hamburguesa{border:.2em solid var(--shade-0);border-radius:.5em;display:none;align-items:center;justify-content:center;aspect-ratio:1;margin-right:1em}.jl-header__menu-hamburguesa:hover,.jl-header__menu-hamburguesa:focus{border-color:var(--primary-lighter)}.jl-header__menu-hamburguesa:hover .jl-header__icon-hamburguesa-line,.jl-header__menu-hamburguesa:focus .jl-header__icon-hamburguesa-line{background-color:var(--primary-lighter)}.jl-header__menu-hamburguesa:active{border-color:var(--primary-light)}.jl-header__menu-hamburguesa:active .jl-header__icon-hamburguesa-line{background-color:var(--primary-light)}.jl-header__title{font-size:2em;font-family:var(--font-title);margin-right:auto}.jl-header__menu-list{display:flex;flex-direction:row;gap:1.6em;list-style-type:none;margin:0;padding:0}.jl-header__menu-item{cursor:pointer;text-decoration:none}.jl-header__menu-item:hover,.jl-header__menu-item:focus{scale:1.1}.jl-header__menu-item:active{scale:.9}.jl-header__menu-link{color:var(--shade-0);font-weight:700;font-size:1.5em}.jl-header__menu-link:hover,.jl-header__menu-link:focus{color:var(--primary-lighter)}.jl-header__menu-link:active{color:var(--primary-light)}.jl-header__darkmode-switch{color:var(--shade-0);font-size:1.5em;font-weight:700;margin-left:.6em}.jl-header__darkmode-switch:hover,.jl-header__darkmode-switch:focus{color:var(--primary-lighter);scale:1.1}.jl-header__darkmode-switch:active{color:var(--primary-light);scale:.9}@media(max-width:1100px){.jl-header__title{font-size:1.6em}.jl-header__menu-list{gap:.8em}.jl-header__menu-link{font-size:1.2em}}@media(max-width:800px){.jl-header__menu{display:none;position:absolute;top:5em;left:0;background-color:var(--primary-light);padding:1em .2em;border-radius:0 0 .5em .5em;box-shadow:.3em .3em .3em .1em var(--shade-200)}.jl-header__menu-hamburguesa{display:flex}.jl-header__menu-hamburguesa:has(.jl-header__icon-hamburguesa--opened)~.jl-header__menu{display:flex}.jl-header__menu-list{flex-direction:column;gap:0;overflow:hidden;padding-right:1em}.jl-header__menu-item{width:100%;display:flex;align-items:center;padding:.8em}.jl-header__menu-item:hover{background-color:var(--primary-lighter);left:5%;position:relative}.jl-header__menu-link{color:var(--primary-darker)}.jl-header__menu-link:hover,.jl-header__menu-link:active,.jl-header__menu-link:focus{color:var(--primary-darker)}}\n"] }]
        }], propDecorators: { links: [{
                type: Input
            }], showThemeButton: [{
                type: Input
            }], darkMode: [{
                type: Input
            }], useInternalThemeService: [{
                type: Input
            }], darkModeChange: [{
                type: Output
            }] } });

class ScrollToTop {
    /** La cantidad de px que debe scrollear para que se muestre el botón
     *  @default 125 */
    scrollHeightToShow = 125;
    pawSVGRef;
    showButton = false;
    scrolling = false;
    detectIfScrolled() {
        if (!this.scrolling) {
            this.showButton = window.scrollY >= this.scrollHeightToShow;
        }
    }
    scrollToTop() {
        this.showButton = false;
        this.scrolling = true;
        if (this.pawSVGRef) {
            this.pawSVGRef.nativeElement.getAnimations().forEach((animation) => {
                animation.currentTime = 0;
                animation.play();
            });
        }
        setTimeout(() => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }, 480);
        setTimeout(() => {
            this.scrolling = false;
        }, 1200);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: ScrollToTop, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.15", type: ScrollToTop, isStandalone: true, selector: "jl-scroll-to-top", inputs: { scrollHeightToShow: "scrollHeightToShow" }, host: { listeners: { "window:scroll": "detectIfScrolled()" } }, viewQueries: [{ propertyName: "pawSVGRef", first: true, predicate: ["pawSVG"], descendants: true }], ngImport: i0, template: "<div class=\"jl-scroll-to-top\">\n  @if (showButton) {\n    <button\n      class=\"jl-icon-btn jl-scroll-to-top__button\"\n      (click)=\"scrollToTop()\"\n      aria-label=\"Ir hacia arriba\"\n      animate.enter=\"jl-fly-in\"\n      animate.leave=\"jl-fly-out\"\n    >\n      <div class=\"jl-scroll-to-top__huella-deditos\">\n        <div class=\"jl-scroll-to-top__huella-dedo jl-scroll-to-top__huella-dedo--one\"></div>\n        <div class=\"jl-scroll-to-top__huella-dedo jl-scroll-to-top__huella-dedo--two\"></div>\n        <div class=\"jl-scroll-to-top__huella-dedo jl-scroll-to-top__huella-dedo--three\"></div>\n        <div class=\"jl-scroll-to-top__huella-dedo jl-scroll-to-top__huella-dedo--four\"></div>\n      </div>\n      <div class=\"jl-scroll-to-top__huella-centro\">\n        <div class=\"jl-scroll-to-top__huella-icon pi pi-chevron-up\"></div>\n      </div>\n    </button>\n  }\n  <svg\n    width=\"219\"\n    height=\"551\"\n    viewBox=\"0 0 219 551\"\n    fill=\"none\"\n    xmlns=\"http://www.w3.org/2000/svg\"\n    class=\"jl-scroll-to-top__paw\"\n    #pawSVG\n  >\n    <g filter=\"url(#filter0_d_1_4364)\">\n      <path\n        d=\"M9.89975 59.0313C-7.04555 91.282 17.8997 193.589 17.8997 307.031C20.0998 337.021 28 396 28 435C28 474 39.1667 519.667 43 543L198.9 537C201.273 523.833 193 465 193 423.5C193 385.471 196.526 339.188 198.9 307.031C198.4 279.031 204.82 223.189 206.02 193.589C207.52 156.589 219.187 168.642 211.9 82.0313C206.52 18.0891 167.9 36.5313 167.9 36.5313C156.52 -20.9109 110.4 10.0313 110.4 10.0313C86.0195 -11.911 52.0663 5.03127 48.3997 33.0313C41.8997 28.1979 25.3998 29.5313 9.89975 59.0313Z\"\n        fill=\"#CECECE\"\n      />\n    </g>\n    <g filter=\"url(#filter1_f_1_4364)\">\n      <path d=\"M48.514 32.9258L54.514 72.9258\" stroke=\"#5C5C5C\" />\n    </g>\n    <g filter=\"url(#filter2_f_1_4364)\">\n      <path d=\"M109.52 10V47\" stroke=\"#5C5C5C\" />\n    </g>\n    <g filter=\"url(#filter3_f_1_4364)\">\n      <path d=\"M167.513 36.08L161.513 73.08\" stroke=\"#5C5C5C\" />\n    </g>\n    <g filter=\"url(#filter4_f_1_4364)\">\n      <path\n        d=\"M17.0195 264.6C53 264.6 105.917 300.976 138.02 276.119\"\n        stroke-width=\"19\"\n        stroke=\"#AFAFAF\"\n      />\n    </g>\n    <g filter=\"url(#filter5_f_1_4364)\">\n      <path d=\"M21 335.612C56.5 329.5 90 372 142.5 345.426\" stroke-width=\"19\" stroke=\"#AFAFAF\" />\n    </g>\n    <defs>\n      <filter\n        id=\"filter0_d_1_4364\"\n        x=\"0\"\n        y=\"0\"\n        width=\"218.274\"\n        height=\"551\"\n        filterUnits=\"userSpaceOnUse\"\n        color-interpolation-filters=\"sRGB\"\n      >\n        <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\" />\n        <feColorMatrix\n          in=\"SourceAlpha\"\n          type=\"matrix\"\n          values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\"\n          result=\"hardAlpha\"\n        />\n        <feOffset dy=\"4\" />\n        <feGaussianBlur stdDeviation=\"2\" />\n        <feComposite in2=\"hardAlpha\" operator=\"out\" />\n        <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0\" />\n        <feBlend mode=\"normal\" in2=\"BackgroundImageFix\" result=\"effect1_dropShadow_1_4364\" />\n        <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"effect1_dropShadow_1_4364\" result=\"shape\" />\n      </filter>\n      <filter\n        id=\"filter1_f_1_4364\"\n        x=\"44.0195\"\n        y=\"28.8516\"\n        width=\"14.9893\"\n        height=\"48.1484\"\n        filterUnits=\"userSpaceOnUse\"\n        color-interpolation-filters=\"sRGB\"\n      >\n        <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\" />\n        <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"BackgroundImageFix\" result=\"shape\" />\n        <feGaussianBlur stdDeviation=\"2\" result=\"effect1_foregroundBlur_1_4364\" />\n      </filter>\n      <filter\n        id=\"filter2_f_1_4364\"\n        x=\"105.02\"\n        y=\"6\"\n        width=\"9\"\n        height=\"45\"\n        filterUnits=\"userSpaceOnUse\"\n        color-interpolation-filters=\"sRGB\"\n      >\n        <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\" />\n        <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"BackgroundImageFix\" result=\"shape\" />\n        <feGaussianBlur stdDeviation=\"2\" result=\"effect1_foregroundBlur_1_4364\" />\n      </filter>\n      <filter\n        id=\"filter3_f_1_4364\"\n        x=\"157.02\"\n        y=\"32\"\n        width=\"14.9873\"\n        height=\"45.1602\"\n        filterUnits=\"userSpaceOnUse\"\n        color-interpolation-filters=\"sRGB\"\n      >\n        <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\" />\n        <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"BackgroundImageFix\" result=\"shape\" />\n        <feGaussianBlur stdDeviation=\"2\" result=\"effect1_foregroundBlur_1_4364\" />\n      </filter>\n      <filter\n        id=\"filter4_f_1_4364\"\n        x=\"13.0195\"\n        y=\"251.1\"\n        width=\"134.816\"\n        height=\"47.2085\"\n        filterUnits=\"userSpaceOnUse\"\n        color-interpolation-filters=\"sRGB\"\n      >\n        <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\" />\n        <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"BackgroundImageFix\" result=\"shape\" />\n        <feGaussianBlur stdDeviation=\"2\" result=\"effect1_foregroundBlur_1_4364\" />\n      </filter>\n      <filter\n        id=\"filter5_f_1_4364\"\n        x=\"15.3877\"\n        y=\"321.502\"\n        width=\"135.402\"\n        height=\"46.2485\"\n        filterUnits=\"userSpaceOnUse\"\n        color-interpolation-filters=\"sRGB\"\n      >\n        <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\" />\n        <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"BackgroundImageFix\" result=\"shape\" />\n        <feGaussianBlur stdDeviation=\"2\" result=\"effect1_foregroundBlur_1_4364\" />\n      </filter>\n    </defs>\n  </svg>\n</div>\n", styles: [".jl-scroll-to-top{position:fixed;bottom:0;right:0}.jl-scroll-to-top__paw{position:absolute;bottom:-50vh;height:50vh;right:0;transform:translate(15%);animation:none;animation-name:scroller-paw;animation-duration:1.2s;animation-timing-function:linear;animation-play-state:paused;animation-fill-mode:forwards}.jl-scroll-to-top__huella-centro{border-radius:100%;background-color:var(--primary-darker);width:4.69em;height:4.69em;display:flex;align-items:center;justify-content:center}.jl-scroll-to-top__huella-icon{color:var(--shade-0);font-weight:700;font-size:3em}.jl-scroll-to-top__huella-deditos{display:grid;width:100%;grid-template-columns:repeat(4,1fr);position:relative;left:-1.2em;top:1em}.jl-scroll-to-top__huella-dedo{border-radius:100%;background-color:var(--primary-darker);width:1.75em;height:2em}.jl-scroll-to-top__huella-dedo--two,.jl-scroll-to-top__huella-dedo--three{position:relative;top:-1.2em}.jl-scroll-to-top__huella-dedo--two{left:-.1em}.jl-scroll-to-top__huella-dedo--three{left:.1em}.jl-scroll-to-top__button{cursor:pointer;width:7.4em;height:7.4em;position:relative}.jl-scroll-to-top__button:hover,.jl-scroll-to-top__button:focus,.jl-scroll-to-top__button:focus-visible{outline:none!important}.jl-scroll-to-top__button:hover .jl-scroll-to-top__huella-centro,.jl-scroll-to-top__button:hover .jl-scroll-to-top__huella-dedo,.jl-scroll-to-top__button:focus .jl-scroll-to-top__huella-centro,.jl-scroll-to-top__button:focus .jl-scroll-to-top__huella-dedo,.jl-scroll-to-top__button:focus-visible .jl-scroll-to-top__huella-centro,.jl-scroll-to-top__button:focus-visible .jl-scroll-to-top__huella-dedo{background-color:var(--primary-dark);box-shadow:0 .25em .25em #00000040}.jl-scroll-to-top__button:active>*{scale:.9}@keyframes scroller-paw{0%{bottom:-50vh;scale:1}35%{bottom:-6vh;scale:1}40%{scale:.8}to{bottom:-50vh}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: ScrollToTop, decorators: [{
            type: Component,
            args: [{ selector: 'jl-scroll-to-top', imports: [CommonModule], template: "<div class=\"jl-scroll-to-top\">\n  @if (showButton) {\n    <button\n      class=\"jl-icon-btn jl-scroll-to-top__button\"\n      (click)=\"scrollToTop()\"\n      aria-label=\"Ir hacia arriba\"\n      animate.enter=\"jl-fly-in\"\n      animate.leave=\"jl-fly-out\"\n    >\n      <div class=\"jl-scroll-to-top__huella-deditos\">\n        <div class=\"jl-scroll-to-top__huella-dedo jl-scroll-to-top__huella-dedo--one\"></div>\n        <div class=\"jl-scroll-to-top__huella-dedo jl-scroll-to-top__huella-dedo--two\"></div>\n        <div class=\"jl-scroll-to-top__huella-dedo jl-scroll-to-top__huella-dedo--three\"></div>\n        <div class=\"jl-scroll-to-top__huella-dedo jl-scroll-to-top__huella-dedo--four\"></div>\n      </div>\n      <div class=\"jl-scroll-to-top__huella-centro\">\n        <div class=\"jl-scroll-to-top__huella-icon pi pi-chevron-up\"></div>\n      </div>\n    </button>\n  }\n  <svg\n    width=\"219\"\n    height=\"551\"\n    viewBox=\"0 0 219 551\"\n    fill=\"none\"\n    xmlns=\"http://www.w3.org/2000/svg\"\n    class=\"jl-scroll-to-top__paw\"\n    #pawSVG\n  >\n    <g filter=\"url(#filter0_d_1_4364)\">\n      <path\n        d=\"M9.89975 59.0313C-7.04555 91.282 17.8997 193.589 17.8997 307.031C20.0998 337.021 28 396 28 435C28 474 39.1667 519.667 43 543L198.9 537C201.273 523.833 193 465 193 423.5C193 385.471 196.526 339.188 198.9 307.031C198.4 279.031 204.82 223.189 206.02 193.589C207.52 156.589 219.187 168.642 211.9 82.0313C206.52 18.0891 167.9 36.5313 167.9 36.5313C156.52 -20.9109 110.4 10.0313 110.4 10.0313C86.0195 -11.911 52.0663 5.03127 48.3997 33.0313C41.8997 28.1979 25.3998 29.5313 9.89975 59.0313Z\"\n        fill=\"#CECECE\"\n      />\n    </g>\n    <g filter=\"url(#filter1_f_1_4364)\">\n      <path d=\"M48.514 32.9258L54.514 72.9258\" stroke=\"#5C5C5C\" />\n    </g>\n    <g filter=\"url(#filter2_f_1_4364)\">\n      <path d=\"M109.52 10V47\" stroke=\"#5C5C5C\" />\n    </g>\n    <g filter=\"url(#filter3_f_1_4364)\">\n      <path d=\"M167.513 36.08L161.513 73.08\" stroke=\"#5C5C5C\" />\n    </g>\n    <g filter=\"url(#filter4_f_1_4364)\">\n      <path\n        d=\"M17.0195 264.6C53 264.6 105.917 300.976 138.02 276.119\"\n        stroke-width=\"19\"\n        stroke=\"#AFAFAF\"\n      />\n    </g>\n    <g filter=\"url(#filter5_f_1_4364)\">\n      <path d=\"M21 335.612C56.5 329.5 90 372 142.5 345.426\" stroke-width=\"19\" stroke=\"#AFAFAF\" />\n    </g>\n    <defs>\n      <filter\n        id=\"filter0_d_1_4364\"\n        x=\"0\"\n        y=\"0\"\n        width=\"218.274\"\n        height=\"551\"\n        filterUnits=\"userSpaceOnUse\"\n        color-interpolation-filters=\"sRGB\"\n      >\n        <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\" />\n        <feColorMatrix\n          in=\"SourceAlpha\"\n          type=\"matrix\"\n          values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\"\n          result=\"hardAlpha\"\n        />\n        <feOffset dy=\"4\" />\n        <feGaussianBlur stdDeviation=\"2\" />\n        <feComposite in2=\"hardAlpha\" operator=\"out\" />\n        <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0\" />\n        <feBlend mode=\"normal\" in2=\"BackgroundImageFix\" result=\"effect1_dropShadow_1_4364\" />\n        <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"effect1_dropShadow_1_4364\" result=\"shape\" />\n      </filter>\n      <filter\n        id=\"filter1_f_1_4364\"\n        x=\"44.0195\"\n        y=\"28.8516\"\n        width=\"14.9893\"\n        height=\"48.1484\"\n        filterUnits=\"userSpaceOnUse\"\n        color-interpolation-filters=\"sRGB\"\n      >\n        <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\" />\n        <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"BackgroundImageFix\" result=\"shape\" />\n        <feGaussianBlur stdDeviation=\"2\" result=\"effect1_foregroundBlur_1_4364\" />\n      </filter>\n      <filter\n        id=\"filter2_f_1_4364\"\n        x=\"105.02\"\n        y=\"6\"\n        width=\"9\"\n        height=\"45\"\n        filterUnits=\"userSpaceOnUse\"\n        color-interpolation-filters=\"sRGB\"\n      >\n        <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\" />\n        <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"BackgroundImageFix\" result=\"shape\" />\n        <feGaussianBlur stdDeviation=\"2\" result=\"effect1_foregroundBlur_1_4364\" />\n      </filter>\n      <filter\n        id=\"filter3_f_1_4364\"\n        x=\"157.02\"\n        y=\"32\"\n        width=\"14.9873\"\n        height=\"45.1602\"\n        filterUnits=\"userSpaceOnUse\"\n        color-interpolation-filters=\"sRGB\"\n      >\n        <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\" />\n        <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"BackgroundImageFix\" result=\"shape\" />\n        <feGaussianBlur stdDeviation=\"2\" result=\"effect1_foregroundBlur_1_4364\" />\n      </filter>\n      <filter\n        id=\"filter4_f_1_4364\"\n        x=\"13.0195\"\n        y=\"251.1\"\n        width=\"134.816\"\n        height=\"47.2085\"\n        filterUnits=\"userSpaceOnUse\"\n        color-interpolation-filters=\"sRGB\"\n      >\n        <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\" />\n        <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"BackgroundImageFix\" result=\"shape\" />\n        <feGaussianBlur stdDeviation=\"2\" result=\"effect1_foregroundBlur_1_4364\" />\n      </filter>\n      <filter\n        id=\"filter5_f_1_4364\"\n        x=\"15.3877\"\n        y=\"321.502\"\n        width=\"135.402\"\n        height=\"46.2485\"\n        filterUnits=\"userSpaceOnUse\"\n        color-interpolation-filters=\"sRGB\"\n      >\n        <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\" />\n        <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"BackgroundImageFix\" result=\"shape\" />\n        <feGaussianBlur stdDeviation=\"2\" result=\"effect1_foregroundBlur_1_4364\" />\n      </filter>\n    </defs>\n  </svg>\n</div>\n", styles: [".jl-scroll-to-top{position:fixed;bottom:0;right:0}.jl-scroll-to-top__paw{position:absolute;bottom:-50vh;height:50vh;right:0;transform:translate(15%);animation:none;animation-name:scroller-paw;animation-duration:1.2s;animation-timing-function:linear;animation-play-state:paused;animation-fill-mode:forwards}.jl-scroll-to-top__huella-centro{border-radius:100%;background-color:var(--primary-darker);width:4.69em;height:4.69em;display:flex;align-items:center;justify-content:center}.jl-scroll-to-top__huella-icon{color:var(--shade-0);font-weight:700;font-size:3em}.jl-scroll-to-top__huella-deditos{display:grid;width:100%;grid-template-columns:repeat(4,1fr);position:relative;left:-1.2em;top:1em}.jl-scroll-to-top__huella-dedo{border-radius:100%;background-color:var(--primary-darker);width:1.75em;height:2em}.jl-scroll-to-top__huella-dedo--two,.jl-scroll-to-top__huella-dedo--three{position:relative;top:-1.2em}.jl-scroll-to-top__huella-dedo--two{left:-.1em}.jl-scroll-to-top__huella-dedo--three{left:.1em}.jl-scroll-to-top__button{cursor:pointer;width:7.4em;height:7.4em;position:relative}.jl-scroll-to-top__button:hover,.jl-scroll-to-top__button:focus,.jl-scroll-to-top__button:focus-visible{outline:none!important}.jl-scroll-to-top__button:hover .jl-scroll-to-top__huella-centro,.jl-scroll-to-top__button:hover .jl-scroll-to-top__huella-dedo,.jl-scroll-to-top__button:focus .jl-scroll-to-top__huella-centro,.jl-scroll-to-top__button:focus .jl-scroll-to-top__huella-dedo,.jl-scroll-to-top__button:focus-visible .jl-scroll-to-top__huella-centro,.jl-scroll-to-top__button:focus-visible .jl-scroll-to-top__huella-dedo{background-color:var(--primary-dark);box-shadow:0 .25em .25em #00000040}.jl-scroll-to-top__button:active>*{scale:.9}@keyframes scroller-paw{0%{bottom:-50vh;scale:1}35%{bottom:-6vh;scale:1}40%{scale:.8}to{bottom:-50vh}}\n"] }]
        }], propDecorators: { scrollHeightToShow: [{
                type: Input
            }], pawSVGRef: [{
                type: ViewChild,
                args: ['pawSVG']
            }], detectIfScrolled: [{
                type: HostListener,
                args: ['window:scroll']
            }] } });

class SectionScroller {
    sections = [];
    scrollTopOffset = 144;
    viewportScroller = inject(ViewportScroller);
    router = inject(Router);
    route = inject(ActivatedRoute);
    routerSuscription;
    selectedItemID = '';
    HTMLHeadingElements = [];
    savedJSON = '';
    ngOnInit() {
        this.viewportScroller.setOffset([0, this.scrollTopOffset]);
        this.routerSuscription = this.router.events.subscribe((navigationEvent) => {
            if (navigationEvent instanceof NavigationEnd) {
                const URLArray = navigationEvent.urlAfterRedirects.split('#');
                const fragment = URLArray[URLArray.length - 1];
                this.viewportScroller.scrollToAnchor(fragment, { behavior: 'smooth' });
                this.selectedItemID = fragment;
            }
            if (navigationEvent instanceof NavigationSkipped && navigationEvent.code === NavigationSkippedCode.IgnoredSameUrlNavigation) {
                const fragment = this.route.snapshot.fragment ?? "";
                this.viewportScroller.scrollToAnchor(fragment, { behavior: 'smooth' });
                this.selectedItemID = fragment;
            }
        });
    }
    ngDoCheck() {
        const JSONSections = JSON.stringify(this.sections);
        if (JSONSections !== this.savedJSON) {
            this.savedJSON = JSONSections;
            this.HTMLHeadingElements = [];
            this.getHeaders();
        }
    }
    ngOnDestroy() {
        if (this.routerSuscription) {
            this.routerSuscription.unsubscribe();
        }
    }
    detectSection() {
        this.getHeaders();
        for (let headingIndex = 0; headingIndex < this.HTMLHeadingElements.length; headingIndex++) {
            const heading = this.HTMLHeadingElements[headingIndex];
            const rect = heading.getBoundingClientRect();
            const topShown = rect.top >= 0;
            const bottomShown = rect.bottom <= window.innerHeight;
            const isShown = topShown && bottomShown;
            if (isShown) {
                this.selectedItemID = heading.id;
                break;
            }
        }
    }
    getHeaders() {
        if (this.HTMLHeadingElements.length <= 0 && this.sections.length > 0) {
            this.sections.forEach((sectionData) => {
                const headingElement = document.getElementById(sectionData.itemID);
                if (headingElement) {
                    this.HTMLHeadingElements.push(headingElement);
                }
            });
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: SectionScroller, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.15", type: SectionScroller, isStandalone: true, selector: "jl-section-scroller", inputs: { sections: "sections", scrollTopOffset: "scrollTopOffset" }, host: { listeners: { "window:scroll": "detectSection()" } }, ngImport: i0, template: "<nav class=\"jl-section-scroller\">\n  <div class=\"jl-section-scroller__background\"></div>\n  <ul class=\"jl-section-scroller__list\">\n    @for (tab of sections; track tab.itemID) {\n      <li class=\"jl-section-scroller__item\">\n        <a\n          [routerLink]=\"[]\"\n          [fragment]=\"tab.itemID\"\n          [ngClass]=\"{\n            'jl-section-scroller__tab': true,\n            'jl-section-scroller__tab--active': tab.itemID === selectedItemID,\n          }\"\n        >\n          <div class=\"jl-section-scroller__label\">{{ tab.label }}</div>\n          @if (tab.imgSrc) {\n            <picture class=\"jl-section-scroller__picture\">\n              @for (imgSrc of tab.imgSrc; track imgSrc) {\n                @if ($last) {\n                  <img [src]=\"imgSrc\" alt=\"\" />\n                } @else {\n                  <source [srcset]=\"imgSrc\" />\n                }\n              }\n            </picture>\n          }\n        </a>\n      </li>\n    }\n  </ul>\n</nav>\n", styles: [".jl-section-scroller{position:sticky;top:6em;left:0}.jl-section-scroller__background{filter:blur(.2em);background-color:color-mix(in srgb,var(--shade-0) 80%,transparent);border-radius:2em;width:100%;height:100%;position:absolute;z-index:0;top:0;left:0}.jl-section-scroller__list{position:relative;z-index:1;list-style-type:none;display:flex;flex-direction:row;align-items:center;justify-content:space-around;gap:1.8em;margin:0;overflow:auto;padding:.5em}.jl-section-scroller__item{display:flex;place-items:center}.jl-section-scroller__picture{position:absolute;right:-.6em;top:50%;transform:translate(50%,-50%);aspect-ratio:1;width:3em;display:flex;align-items:center;justify-content:center}.jl-section-scroller__tab{position:relative;background-color:var(--primary-dark);border-radius:1em;padding:.6em 1.2em;color:var(--shade-0);cursor:pointer;text-decoration:none;font-weight:700}.jl-section-scroller__tab:not(.jl-section-scroller__tab--active):hover{color:var(--shade-100)}.jl-section-scroller__tab:not(.jl-section-scroller__tab--active):hover .jl-section-scroller__picture{scale:1.05}.jl-section-scroller__tab:has(.jl-section-scroller__picture){margin-right:.9em}.jl-section-scroller__tab--active{background-color:var(--primary-darker);font-weight:bolder}.jl-section-scroller__tab--active .jl-section-scroller__picture{scale:1.15}\n"], dependencies: [{ kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: CommonModule }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.15", ngImport: i0, type: SectionScroller, decorators: [{
            type: Component,
            args: [{ selector: 'jl-section-scroller', imports: [RouterLink, NgClass, CommonModule], template: "<nav class=\"jl-section-scroller\">\n  <div class=\"jl-section-scroller__background\"></div>\n  <ul class=\"jl-section-scroller__list\">\n    @for (tab of sections; track tab.itemID) {\n      <li class=\"jl-section-scroller__item\">\n        <a\n          [routerLink]=\"[]\"\n          [fragment]=\"tab.itemID\"\n          [ngClass]=\"{\n            'jl-section-scroller__tab': true,\n            'jl-section-scroller__tab--active': tab.itemID === selectedItemID,\n          }\"\n        >\n          <div class=\"jl-section-scroller__label\">{{ tab.label }}</div>\n          @if (tab.imgSrc) {\n            <picture class=\"jl-section-scroller__picture\">\n              @for (imgSrc of tab.imgSrc; track imgSrc) {\n                @if ($last) {\n                  <img [src]=\"imgSrc\" alt=\"\" />\n                } @else {\n                  <source [srcset]=\"imgSrc\" />\n                }\n              }\n            </picture>\n          }\n        </a>\n      </li>\n    }\n  </ul>\n</nav>\n", styles: [".jl-section-scroller{position:sticky;top:6em;left:0}.jl-section-scroller__background{filter:blur(.2em);background-color:color-mix(in srgb,var(--shade-0) 80%,transparent);border-radius:2em;width:100%;height:100%;position:absolute;z-index:0;top:0;left:0}.jl-section-scroller__list{position:relative;z-index:1;list-style-type:none;display:flex;flex-direction:row;align-items:center;justify-content:space-around;gap:1.8em;margin:0;overflow:auto;padding:.5em}.jl-section-scroller__item{display:flex;place-items:center}.jl-section-scroller__picture{position:absolute;right:-.6em;top:50%;transform:translate(50%,-50%);aspect-ratio:1;width:3em;display:flex;align-items:center;justify-content:center}.jl-section-scroller__tab{position:relative;background-color:var(--primary-dark);border-radius:1em;padding:.6em 1.2em;color:var(--shade-0);cursor:pointer;text-decoration:none;font-weight:700}.jl-section-scroller__tab:not(.jl-section-scroller__tab--active):hover{color:var(--shade-100)}.jl-section-scroller__tab:not(.jl-section-scroller__tab--active):hover .jl-section-scroller__picture{scale:1.05}.jl-section-scroller__tab:has(.jl-section-scroller__picture){margin-right:.9em}.jl-section-scroller__tab--active{background-color:var(--primary-darker);font-weight:bolder}.jl-section-scroller__tab--active .jl-section-scroller__picture{scale:1.15}\n"] }]
        }], propDecorators: { sections: [{
                type: Input
            }], scrollTopOffset: [{
                type: Input
            }], detectSection: [{
                type: HostListener,
                args: ['window:scroll']
            }] } });

/*
 * Public API Surface of josslib
 * Components
 */

/**
 * Generated bundle index. Do not edit.
 */

export { Header, Josslib, ScrollToTop, SectionScroller, ThemeService };
//# sourceMappingURL=josslib.mjs.map
