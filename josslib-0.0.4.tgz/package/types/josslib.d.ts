import * as i0 from '@angular/core';
import { AfterViewInit, EventEmitter, ElementRef, OnInit, OnDestroy, DoCheck } from '@angular/core';
import { ViewportScroller } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';

declare class Josslib {
    static ɵfac: i0.ɵɵFactoryDeclaration<Josslib, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Josslib, "lib-josslib", never, {}, {}, never, never, true, never>;
}

declare class ThemeService {
    private document;
    constructor(document: Document);
    darkMode: boolean;
    temas: string[];
    loadTheme(): void;
    switchTheme(): void;
    getTheme(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThemeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ThemeService>;
}

interface IHeaderLink {
    label: string;
    link: string;
}
declare class Header implements AfterViewInit {
    links: IHeaderLink[];
    showThemeButton: boolean;
    darkMode: boolean;
    useInternalThemeService: boolean;
    darkModeChange: EventEmitter<boolean>;
    openedMenu: boolean;
    themeService: ThemeService;
    ngAfterViewInit(): void;
    switchTheme(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<Header, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Header, "jl-header", never, { "links": { "alias": "links"; "required": false; }; "showThemeButton": { "alias": "showThemeButton"; "required": false; }; "darkMode": { "alias": "darkMode"; "required": false; }; "useInternalThemeService": { "alias": "useInternalThemeService"; "required": false; }; }, { "darkModeChange": "darkModeChange"; }, never, never, true, never>;
}

declare class ScrollToTop {
    /** La cantidad de px que debe scrollear para que se muestre el botón
     *  @default 125 */
    scrollHeightToShow: number;
    pawSVGRef: ElementRef<SVGElement> | undefined;
    showButton: boolean;
    scrolling: boolean;
    detectIfScrolled(): void;
    scrollToTop(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScrollToTop, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ScrollToTop, "jl-scroll-to-top", never, { "scrollHeightToShow": { "alias": "scrollHeightToShow"; "required": false; }; }, {}, never, never, true, never>;
}

interface ISectionHeader {
    label: string;
    itemID: string;
    imgSrc?: string[];
}
declare class SectionScroller implements OnInit, OnDestroy, DoCheck {
    sections: ISectionHeader[];
    scrollTopOffset: number;
    viewportScroller: ViewportScroller;
    router: Router;
    route: ActivatedRoute;
    routerSuscription: Subscription | undefined;
    selectedItemID: string;
    HTMLHeadingElements: HTMLHeadingElement[];
    savedJSON: string;
    ngOnInit(): void;
    ngDoCheck(): void;
    ngOnDestroy(): void;
    detectSection(): void;
    getHeaders(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SectionScroller, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SectionScroller, "jl-section-scroller", never, { "sections": { "alias": "sections"; "required": false; }; "scrollTopOffset": { "alias": "scrollTopOffset"; "required": false; }; }, {}, never, never, true, never>;
}

export { Header, Josslib, ScrollToTop, SectionScroller, ThemeService };
export type { IHeaderLink, ISectionHeader };
